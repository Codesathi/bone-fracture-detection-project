import numpy as np
import tensorflow as tf
from keras.preprocessing import image
import random  # Added for random severity selection

# Load the models when importing "predictions.py"
model_elbow_frac = tf.keras.models.load_model("weights/ResNet50_Elbow_frac.h5")
model_hand_frac = tf.keras.models.load_model("weights/ResNet50_Hand_frac.h5")
model_shoulder_frac = tf.keras.models.load_model("weights/ResNet50_Shoulder_frac.h5")
model_parts = tf.keras.models.load_model("weights/ResNet50_BodyParts.h5")

# Categories for each result by index

#   0-Elbow     1-Hand      2-Shoulder
categories_parts = ["Elbow", "Hand", "Shoulder"]

#   0-fractured     1-normal
categories_fracture = ['fractured', 'normal']

# Get image and model name, the default model is "Parts"
# Parts - bone type predict model of 3 classes
# Otherwise - fracture predict for each part
def predict(img, model="Parts"):
    size = 224
    if model == 'Parts':
        chosen_model = model_parts
    else:
        if model == 'Elbow':
            chosen_model = model_elbow_frac
        elif model == 'Hand':
            chosen_model = model_hand_frac
        elif model == 'Shoulder':
            chosen_model = model_shoulder_frac

    # Load image with 224px x 224px (the training model image size, rgb)
    temp_img = image.load_img(img, target_size=(size, size))
    x = image.img_to_array(temp_img)
    x = np.expand_dims(x, axis=0)
    images = np.vstack([x])
    prediction = np.argmax(chosen_model.predict(images), axis=1)

    # Choose the category and get the string prediction
    if model == 'Parts':
        prediction_str = categories_parts[prediction.item()]
    else:
        prediction_str = categories_fracture[prediction.item()]

    return prediction_str

# Function to get severity and medication based on the prediction result
def get_severity_and_medication(result, bone_type):
    if result == 'fractured':
        severity_levels = ["Low", "Medium", "High"]
        severity = random.choice(severity_levels)  # Randomly choose severity for demonstration

        if severity == "Low":
            medication = "Rest, ice, and over-the-counter pain relievers."
        elif severity == "Medium":
            medication = "Ibuprofen(Advil),Acetaminophen(Tylenol),Pain relievers(Tramadol),Nonsteroidal anti-inflammatory drugs(NSAIDs)and possibly a splint or brace."
        else:  # High severity
            medication = "Strong Pain Relievers:Opioids(morphine),anti-inflammatory drugs,Antibiotics(cefazolin),immobilization,and consult an orthopedic specialist."

    else:
        severity = None
        medication = None

    return severity, medication
